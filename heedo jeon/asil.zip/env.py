CITY_CODE_PATH = './city_code.xlsx'
DEFAULT_ENCODING = 'utf-8-sig'